from __future__ import annotations

import hashlib
import json
import secrets
import sqlite3
import time
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from flask import Flask, current_app, g
from werkzeug.security import generate_password_hash

from .http import ApiError

MIGRATIONS_DIR = Path(__file__).with_name("migrations")

SEED_USERS = (
    ("teacher-a", "teacher", "class-a"),
    ("student-a", "student", "class-a"),
    ("teacher-b", "teacher", "class-b"),
    ("student-b", "student", "class-b"),
)


def utc_now() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat()


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        database = Path(current_app.config["DATABASE_PATH"])
        database.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(database)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        g.db = connection
    return g.db


def close_db(_error: BaseException | None = None) -> None:
    connection = g.pop("db", None)
    if connection is not None:
        connection.close()


def _seed_users(connection: sqlite3.Connection, app: Flask) -> None:
    passwords = {
        "teacher": app.config["SEED_TEACHER_PASSWORD"],
        "student": app.config["SEED_STUDENT_PASSWORD"],
    }
    hashes: dict[str, str] = {}
    for username, role, class_id in SEED_USERS:
        if role not in hashes:
            hashes[role] = generate_password_hash(passwords[role])
        connection.execute(
            """
            INSERT INTO users(username, password_hash, role, class_id, created_at)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(username) DO NOTHING
            """,
            (username, hashes[role], role, class_id, utc_now()),
        )


def _apply_migrations(connection: sqlite3.Connection) -> None:
    # Serialize both version discovery and DDL across gunicorn workers.
    connection.execute("BEGIN IMMEDIATE")
    try:
        connection.execute(
            "CREATE TABLE IF NOT EXISTS schema_migrations "
            "(version TEXT PRIMARY KEY, applied_at TEXT NOT NULL)"
        )
        applied = {row[0] for row in connection.execute("SELECT version FROM schema_migrations")}
        for migration in sorted(MIGRATIONS_DIR.glob("*.sql")):
            if migration.name in applied:
                continue
            statement = ""
            for line in migration.read_text(encoding="utf-8").splitlines(keepends=True):
                statement += line
                if sqlite3.complete_statement(statement):
                    connection.execute(statement)
                    statement = ""
            if statement.strip():
                raise ValueError(f"Incomplete migration: {migration.name}")
            connection.execute(
                "INSERT INTO schema_migrations(version,applied_at) VALUES(?,?)",
                (migration.name, utc_now()),
            )
        connection.commit()
    except Exception:
        connection.rollback()
        raise


def init_db(app: Flask) -> None:
    with app.app_context():
        connection = get_db()
        _apply_migrations(connection)
        _seed_users(connection, app)
        connection.commit()


def database_is_ready() -> bool:
    try:
        return get_db().execute("SELECT 1").fetchone()[0] == 1
    except sqlite3.Error:
        return False


def get_user_by_username(username: str) -> sqlite3.Row | None:
    return (
        get_db()
        .execute(
            "SELECT id, username, password_hash, role, class_id FROM users WHERE username = ?",
            (username,),
        )
        .fetchone()
    )


def create_session(*, jti: str, user_id: int, expires_at: str, created_at: str) -> None:
    connection = get_db()
    connection.execute(
        """
        INSERT INTO auth_sessions(jti, user_id, expires_at, created_at)
        VALUES (?, ?, ?, ?)
        """,
        (jti, user_id, expires_at, created_at),
    )
    connection.commit()


def get_active_session(jti: str) -> sqlite3.Row | None:
    return (
        get_db()
        .execute(
            """
        SELECT s.jti, s.expires_at, u.id, u.username, u.role, u.class_id
        FROM auth_sessions s
        JOIN users u ON u.id = s.user_id
        WHERE s.jti = ? AND s.revoked_at IS NULL AND s.expires_at > ?
        """,
            (jti, utc_now()),
        )
        .fetchone()
    )


def revoke_session(jti: str) -> None:
    connection = get_db()
    connection.execute(
        "UPDATE auth_sessions SET revoked_at = ? WHERE jti = ? AND revoked_at IS NULL",
        (utc_now(), jti),
    )
    connection.commit()


def list_materials(class_id: str) -> list[sqlite3.Row]:
    return list(
        get_db()
        .execute(
            """
            SELECT id, title, filename, created_at
            FROM materials
            WHERE class_id = ?
            ORDER BY created_at DESC, id DESC
            """,
            (class_id,),
        )
        .fetchall()
    )


def create_material(
    *,
    class_id: str,
    title: str,
    filename: str,
    created_by: int,
    chunks: list[dict[str, Any]],
    session_id: str | None = None,
    event_id: str | None = None,
) -> int:
    connection = get_db()
    connection.execute("BEGIN IMMEDIATE")
    actor = get_active_session(session_id) if session_id else None
    status = 401 if actor is None else (403 if actor["role"] != "teacher" else 0)
    if not status and (actor["class_id"] != class_id or actor["id"] != created_by):
        status = 404
    if status:
        connection.rollback()
        record_operation(
            event_id or secrets.token_hex(16), actor, "materials.upload", "material", status
        )
        raise ApiError(
            code=1100 if status == 401 else (1304 if status == 404 else 1204),
            message="未登录"
            if status == 401
            else ("资源不存在" if status == 404 else "无权执行此操作"),
            status=status,
        )
    created_at = utc_now()
    try:
        cursor = connection.execute(
            """
            INSERT INTO materials(class_id, title, filename, created_by, created_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (class_id, title, filename, created_by, created_at),
        )
        material_id = int(cursor.lastrowid)
        for chunk in chunks:
            cursor = connection.execute(
                """
                INSERT INTO chunks(
                    material_id, class_id, chunk_index, content, start_line, end_line
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    material_id,
                    class_id,
                    chunk["chunk_index"],
                    chunk["content"],
                    chunk["start_line"],
                    chunk["end_line"],
                ),
            )
            connection.execute(
                "INSERT INTO chunks_fts(rowid, content) VALUES (?, ?)",
                (cursor.lastrowid, chunk["content"]),
            )
        connection.execute(
            "INSERT INTO class_revisions(class_id,revision) VALUES(?,1) "
            "ON CONFLICT(class_id) DO UPDATE SET revision=revision+1",
            (class_id,),
        )
        record_operation(
            event_id or secrets.token_hex(16),
            actor,
            "materials.upload",
            f"material:{material_id}",
            201,
            commit=False,
        )
        connection.commit()
        return material_id
    except Exception:
        connection.rollback()
        raise


def get_material_for_class(material_id: int, class_id: str) -> sqlite3.Row | None:
    row = (
        get_db()
        .execute(
            """
        SELECT id, title, filename, created_at, class_id
        FROM materials
        WHERE id = ?
        """,
            (material_id,),
        )
        .fetchone()
    )
    return row if row is not None and row["class_id"] == class_id else None


def list_chunks(material_id: int, class_id: str) -> list[sqlite3.Row]:
    return list(
        get_db()
        .execute(
            """
            SELECT id, chunk_index, content, start_line, end_line
            FROM chunks
            WHERE material_id = ? AND class_id = ?
            ORDER BY chunk_index
            """,
            (material_id, class_id),
        )
        .fetchall()
    )


def search_chunks_by_fts(class_id: str, fts_query: str, limit: int) -> list[sqlite3.Row]:
    return list(
        get_db()
        .execute(
            """
            SELECT
                c.id, c.material_id, c.chunk_index, c.content, c.start_line, c.end_line,
                m.title, bm25(chunks_fts) AS rank
            FROM chunks_fts
            JOIN chunks c ON c.id = chunks_fts.rowid
            JOIN materials m ON m.id = c.material_id
            WHERE chunks_fts MATCH ? AND c.class_id = ?
            ORDER BY rank, c.id
            LIMIT ?
            """,
            (fts_query, class_id, limit),
        )
        .fetchall()
    )


def search_chunks_by_like(class_id: str, terms: list[str], limit: int) -> list[sqlite3.Row]:
    escaped = [term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") for term in terms]
    predicates = " OR ".join("c.content LIKE ? ESCAPE '\\'" for _ in escaped)
    return list(
        get_db()
        .execute(
            f"""
            SELECT
                c.id, c.material_id, c.chunk_index, c.content, c.start_line, c.end_line,
                m.title, 0.0 AS rank
            FROM chunks c
            JOIN materials m ON m.id = c.material_id
            WHERE c.class_id = ? AND ({predicates})
            ORDER BY c.id
            LIMIT ?
            """,
            (class_id, *(f"%{term}%" for term in escaped), limit),
        )
        .fetchall()
    )


def issue_csrf(jti: str, binding: str) -> str:
    token = secrets.token_urlsafe(32)
    get_db().execute(
        "INSERT INTO csrf_tokens(token_hash,jti,binding_hash,expires_at) VALUES(?,?,?,?)",
        (
            hashlib.sha256(token.encode()).hexdigest(),
            jti,
            hashlib.sha256(binding.encode()).hexdigest(),
            (datetime.now(UTC) + timedelta(minutes=10)).isoformat(),
        ),
    )
    get_db().commit()
    return token


def consume_csrf(jti: str, binding: str, token: str) -> bool:
    cursor = get_db().execute(
        "UPDATE csrf_tokens SET used_at=? WHERE token_hash=? AND jti=? "
        "AND binding_hash=? AND expires_at>? AND used_at IS NULL",
        (
            utc_now(),
            hashlib.sha256(token.encode()).hexdigest(),
            jti,
            hashlib.sha256(binding.encode()).hexdigest(),
            utc_now(),
        ),
    )
    get_db().commit()
    return cursor.rowcount == 1


def record_operation(
    event_id: str,
    actor: Any,
    operation: str,
    obj: str,
    status: int,
    duration_ms: float = 0,
    usage: Any = None,
    *,
    commit: bool = True,
) -> None:
    # Values are deliberately restricted to identifiers; no headers or request bodies.
    payload = {
        "actor": {"id": actor["id"], "username": actor["username"]} if actor else None,
        "timestamp": utc_now(),
        "operation": operation[:120],
        "object": obj[:512],
        "result": status,
        "skill_id": None,
        "skill_reason": "not_applicable",
        "usage_and_duration": {"usage": usage, "duration_ms": duration_ms},
        "event_id": event_id,
    }
    encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    if len(encoded.encode()) > 8192:
        raise ValueError("Audit event too large")
    get_db().execute(
        "INSERT INTO operation_logs(event_id,class_id,actor_id,created_at,payload) "
        "VALUES(?,?,?,?,?) ON CONFLICT(event_id) DO NOTHING",
        (
            event_id,
            actor["class_id"] if actor else "",
            actor["id"] if actor else None,
            utc_now(),
            encoded,
        ),
    )
    if commit:
        get_db().commit()


def finish_operation(
    event_id: str,
    actor: Any,
    operation: str,
    status: int,
    duration_ms: float,
    usage: Any = None,
    object_id: int | None = None,
) -> None:
    connection = get_db()
    connection.execute("BEGIN IMMEDIATE")
    try:
        row = connection.execute(
            "SELECT payload FROM operation_logs WHERE event_id=?", (event_id,)
        ).fetchone()
        if row:
            payload = json.loads(row["payload"])
            payload["usage_and_duration"] = {"usage": usage, "duration_ms": duration_ms}
            payload["result"] = status
            connection.execute(
                "UPDATE operation_logs SET payload=? WHERE event_id=?",
                (json.dumps(payload, ensure_ascii=False, separators=(",", ":")), event_id),
            )
        else:
            obj = f"material:{object_id}" if isinstance(object_id, int) else operation
            record_operation(
                event_id, actor, operation, obj, status, duration_ms, usage, commit=False
            )
        if current_app.config.get("TELEMETRY_ENABLED"):
            _aggregate_metric(event_id, operation, status, duration_ms / 1000)
            connection.execute("DELETE FROM request_leases WHERE event_id=?", (event_id,))
        connection.commit()
    except Exception:
        connection.rollback()
        raise


def query_operations(
    class_id: str, actor_id: int | None, start: str, end: str, limit: int, offset: int
) -> list[dict]:
    rows = (
        get_db()
        .execute(
            "SELECT payload FROM operation_logs WHERE class_id=? AND (? IS NULL OR actor_id=?) "
            "AND created_at>=? AND created_at<=? "
            "ORDER BY created_at DESC,id DESC LIMIT ? OFFSET ?",
            (class_id, actor_id, actor_id, start, end, limit, offset),
        )
        .fetchall()
    )
    return [json.loads(row["payload"]) for row in rows]


CAPABILITIES = {
    "materials.upload": "materials-upload",
    "search.find": "knowledge-search",
    "assistant.ask": "grounded-ask",
}
METRIC_BOUNDS = (0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0)


def class_revision(class_id: str) -> int:
    row = (
        get_db()
        .execute("SELECT revision FROM class_revisions WHERE class_id=?", (class_id,))
        .fetchone()
    )
    return row[0] if row else 0


def ready_for_traffic() -> bool:
    try:
        applied = {row[0] for row in get_db().execute("SELECT version FROM schema_migrations")}
        expected = {p.name for p in MIGRATIONS_DIR.glob("*.sql")}
        for table in (
            "users",
            "materials",
            "chunks",
            "operation_logs",
            "class_revisions",
            "metric_totals",
        ):
            get_db().execute(f"SELECT 1 FROM {table} LIMIT 1").fetchone()
        return expected <= applied
    except (sqlite3.Error, OSError):
        return False


def _aggregate_metric(event_id: str, operation: str, status: int, seconds: float) -> None:
    capability = CAPABILITIES.get(operation)
    if capability is None:
        return
    cursor = get_db().execute(
        "INSERT INTO metric_receipts(event_id) VALUES(?) ON CONFLICT DO NOTHING", (event_id,)
    )
    if not cursor.rowcount:
        return
    row = (
        get_db()
        .execute(
            "SELECT n,sum_seconds,buckets FROM metric_totals WHERE capability=? AND status=?",
            (capability, status),
        )
        .fetchone()
    )
    buckets = json.loads(row["buckets"]) if row else [0] * (len(METRIC_BOUNDS) + 1)
    for index, bound in enumerate((*METRIC_BOUNDS, float("inf"))):
        buckets[index] += int(seconds <= bound)
    get_db().execute(
        "INSERT INTO metric_totals(capability,status,n,sum_seconds,buckets) VALUES(?,?,?,?,?) "
        "ON CONFLICT(capability,status) DO UPDATE SET n=excluded.n,"
        "sum_seconds=excluded.sum_seconds,buckets=excluded.buckets",
        (
            capability,
            status,
            (row["n"] if row else 0) + 1,
            (row["sum_seconds"] if row else 0) + seconds,
            json.dumps(buckets),
        ),
    )


def begin_lease(event_id: str, capability: str) -> None:
    with get_db():
        get_db().execute("DELETE FROM request_leases WHERE expires<?", (time.time(),))
        get_db().execute(
            "INSERT INTO request_leases(event_id,capability,expires) VALUES(?,?,?)",
            (event_id, capability, time.time() + 30),
        )


def renew_leases(events: list[str]) -> None:
    with get_db():
        get_db().executemany(
            "UPDATE request_leases SET expires=? WHERE event_id=?",
            [(time.time() + 30, event) for event in events],
        )


def metric_snapshot() -> tuple[list[dict], dict[str, int]]:
    totals = [
        dict(row)
        for row in get_db().execute("SELECT * FROM metric_totals ORDER BY capability,status")
    ]
    active = {
        row["capability"]: row["n"]
        for row in get_db().execute(
            "SELECT capability,count(*) n FROM request_leases WHERE expires>? GROUP BY capability",
            (time.time(),),
        )
    }
    return totals, active
